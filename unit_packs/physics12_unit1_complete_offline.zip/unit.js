const UNIT=window.UNIT_DATA;
const STATE_KEY='samed-unit-state-'+UNIT.id,PROGRESS_KEY='samed-offline-progress-v1';
let state=load(STATE_KEY,{q:0,steps:{},done:{},hints:{}}),pane='';
const $=s=>document.querySelector(s);
function load(k,d){try{return JSON.parse(localStorage.getItem(k))||d}catch(e){return d}}
function save(){localStorage.setItem(STATE_KEY,JSON.stringify(state));metrics()}
function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function attr(v){return esc(v).replace(/`/g,'&#96;')}
function arabicDigits(v){return String(v).replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d))}
function norm(v){return arabicDigits(v).toLowerCase().replace(/[\sـ_{}()]/g,'').replace(/[−–—]/g,'-').replace(/×/g,'*').replace(/⅔/g,'2/3').replace(/½/g,'1/2')}
function num(v){v=arabicDigits(v).trim().replace(/[−–—]/g,'-').replace(/×10\^?/g,'e').replace(/÷/g,'/').replace(',','.');const f=v.match(/^(-?\d+(?:\.\d+)?)\/(-?\d+(?:\.\d+)?)$/);if(f&&Number(f[2])!==0)return Number(f[1])/Number(f[2]);const n=Number(v);return Number.isFinite(n)?n:null}
function close(a,b,t=.01){return Math.abs(a-b)<=Math.max(t,Math.abs(b)*1e-4)}
function toast(m){const t=$('#toast');t.textContent=m;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2200)}

/* مصغّر معادلات محلي: لا CDN ولا نص LaTeX خام. */
function mathHtml(value){
 let s=esc(value??'');
 s=s.replace(/\\(?:mathbf|mathrm|text)\{([^{}]*)\}/g,'<strong>$1</strong>');
 for(let i=0;i<8;i++){
  const before=s;
  s=s.replace(/\\sqrt\{([^{}]*)\}/g,'<span class="root"><span class="radicand">$1</span></span>');
  s=s.replace(/\\frac\{([^{}]*)\}\{([^{}]*)\}/g,'<span class="frac"><span class="num">$1</span><span class="den">$2</span></span>');
  if(s===before)break;
 }
 s=s.replace(/\\(?:left|right)/g,'').replace(/\\cdot/g,'·').replace(/\\times/g,'×').replace(/\\div/g,'÷').replace(/\\pm/g,'±').replace(/\\infty/g,'∞');
 s=s.replace(/\^\{([^{}]+)\}/g,'<sup>$1</sup>').replace(/\^([A-Za-z0-9+\-])/g,'<sup>$1</sup>');
 s=s.replace(/_\{([^{}]+)\}/g,'<sub>$1</sub>').replace(/_([A-Za-z0-9])/g,'<sub>$1</sub>');
 s=s.replace(/\\[;,!]/g,' ').replace(/\\([A-Za-z]+)/g,'$1');
 return '<span class="math-expr" dir="ltr">'+s+'</span>';
}
function proseHtml(v){
 let s=esc(v??'');
 s=s.replace(/_([A-Za-z0-9])/g,'<sub>$1</sub>').replace(/\^([A-Za-z0-9+\-])/g,'<sup>$1</sup>');
 return '<span class="mixed-text">'+s+'</span>';
}
function equationOrText(v){return /\\(?:frac|sqrt|mathbf|text|times|cdot)|[A-Za-z][_^]/.test(String(v??''))?mathHtml(v):proseHtml(v)}
function workNorm(v){return arabicDigits(v??'').replace(/\s+/g,'').replace(/[−–—]/g,'-').replace(/[×xX·]/g,'*').replace(/÷/g,'/').replace(/[(){}]/g,'').replace(/₂/g,'2').replace(/₁/g,'1')}
function summaryExpression(step){if(step.carry_display)return step.carry_display;if(step.completed_display)return step.completed_display;if(step.result_target!==undefined)return (step.result_label||'')+' '+step.result_target;return ''}
function referencesHtml(q,si,step){
 let refs=step.references||[];
 if(!refs.length&&si>0&&state.done[key(q,si-1)]){const x=summaryExpression(q.steps[si-1]);if(x)refs=[{source:si,label:'من الخطوة السابقة',expression:x}]}
 refs=refs.filter(r=>r.source===undefined||state.done[key(q,Math.max(0,r.source-1))]);
 if(!refs.length)return '';
 return `<section class="needed-box"><div class="needed-head">📌 عبارات نحتاجها في هذه الخطوة</div>${refs.map(r=>`<div class="needed-row"><span class="needed-source">${esc(r.label||'استنتاج سابق')}</span><div class="needed-eq">${mathHtml(r.expression)}</div></div>`).join('')}</section>`
}
function guidedWorkHtml(g,done){if(!g||done)return '';return `<section class="guided-work"><div class="guided-title">✍️ ${esc(g.title||'مرحلة وسيطة')}</div><p>${esc(g.instruction||'')}</p><div class="guided-equation"><span>${mathHtml(g.equation_left||'')}</span><input id="guidedWork" autocomplete="off" placeholder="${attr(g.placeholder||'اكتب التحويل')}"></div></section>`}
function microEquationInput(eq,index){const parts=String(eq||'').split('?');if(parts.length<2)return mathHtml(eq);return `${mathHtml(parts.shift())}<input id="micro-${index}" data-micro-answer="1" inputmode="text" autocomplete="off" placeholder="؟">${mathHtml(parts.join('?'))}`}
function microPracticeHtml(step,done){
 if(done)return '';
 const rows=step.micro||[];if(!rows.length)return '';
 return `<section class="micro-practice"><div class="micro-practice-head">🧩 املأ فراغات الخطوات بالترتيب</div><p>اكتب إجابة كل سطر حتى السطر الأخير، ثم اضغط «تحقق».</p>${rows.map((row,i)=>{const p=unitizeRow(rowParts(row),i===rows.length-1);return `<div class="micro-practice-row" data-micro-row="${i}"><span class="micro-practice-index">${i+1}</span><div><div class="micro-practice-desc">${esc(p.desc)}</div>${p.eq?`<div class="micro-practice-eq">${p.target?microEquationInput(p.eq,i):mathHtml(p.eq)}</div>`:''}</div></div>`}).join('')}</section>`
}
function commKey(v,cs){let t=workNorm(v);if(!cs)t=t.toLowerCase();if(/[\u0600-\u06FF]/.test(t))return t;return t.split('=').map(s=>{if(s.length>14||s.includes('/')||s.includes('-'))return s;return s.split('+').map(x=>{const fs=x.split('*').filter(Boolean);return (fs.length===1&&!/[0-9]/.test(fs[0]))?fs[0].split('').sort().join(''):fs.sort().join('*')}).sort().join('+')}).sort().join('=')}
function microValueMatches(value,target,caseSensitive){
 const alternatives=String(target).split('|');
 for(const candidate of alternatives){if(commKey(value,caseSensitive)===commKey(candidate,caseSensitive))return true;const a=num(value),b=num(candidate);if(a!==null&&b!==null&&close(a,b,.001))return true;let got=workNorm(value),want=workNorm(candidate);if(!caseSensitive){got=got.toLowerCase();want=want.toLowerCase()}if(got===want||got.replace(/\*/g,'')===want.replace(/\*/g,''))return true}
 return false
}
function validateMicroPractice(step){
 const rows=step.micro||[];
 for(let i=0;i<rows.length;i++){const p=unitizeRow(rowParts(rows[i]),i===rows.length-1);if(!p.target)continue;const input=document.getElementById('micro-'+i),row=document.querySelector(`[data-micro-row="${i}"]`);if(!input||!String(input.value).trim()){row&&row.classList.add('is-bad');input&&input.focus();toast('أكمل أولاً الفراغ رقم '+(i+1));return false}if(!microValueMatches(input.value,p.target,!!step.case_sensitive)){row&&row.classList.add('is-bad');input.focus();toast('راجع الفراغ رقم '+(i+1));return false}row&&row.classList.remove('is-bad');row&&row.classList.add('is-ok')}
 return true
}
function rowParts(row){const a=Array.isArray(row)?row:[String(row),''];let desc=a[0]||'',eq=String(a[1]||''),t=(a[2]===undefined||a[2]===null)?'':String(a[2]);if(!t&&eq&&eq.indexOf('?')<0&&eq.indexOf('=')>-1){const i=eq.lastIndexOf('='),r=eq.slice(i+1).trim();if(r){t=r;eq=eq.slice(0,i+1)+' ?'}}return{desc:desc,eq:eq,target:t}}
function unitizeRow(p,isLast){if(!isLast||!p.target)return p;const m=/^([\s\S]*\?)\s*([A-Za-z\u00b0%][A-Za-z0-9\u00b7\u00b2\u00b3\/.^-]*)\s*$/.exec(String(p.eq||''));if(!m)return p;const u=m[2];p.eq=m[1];p.desc=String(p.desc||'').replace(/[:\s]+$/,'')+' — اكتب النتيجة مع الوحدة ('+u+')';const vs=[u,u.replace(/\u00b7/g,'.'),u.replace(/\u00b7/g,' '),u.replace(/\u00b7/g,'')],out=[];String(p.target).split('|').forEach(function(a){a=a.trim();if(!a)return;vs.forEach(function(v){v=v.trim();if(!v)return;out.push(a+' '+v);out.push(a+v)})});p.target=out.filter(function(x,i){return out.indexOf(x)===i}).join('|');return p}
function maskAnswer(v){const s=String(v==null?'':v);if(!s||s.indexOf('?')>-1)return s;const i=s.lastIndexOf('=');return (i>-1&&s.slice(i+1).trim())?s.slice(0,i+1)+' ?':s}
function hintHtml(step){const parts=[];if(step.law)parts.push(`<div><b>القانون المستعمل:</b> ${proseHtml(step.law)}</div>`);if(step.simple_explain)parts.push(`<div>💬 ${proseHtml(step.simple_explain)}</div>`);const rows=[...(step.micro||[]),...(step.micro2||[])];if(rows.length){const items=rows.map((r,i)=>{const p=rowParts(r);let eq=p.eq;if(p.target&&i<rows.length-1)eq=eq.replace('?',String(p.target).split('|')[0]);return `<li><b>${i+1}.</b> ${esc(p.desc)}${eq?` <span class="hint-eq">${mathHtml(eq)}</span>`:''}</li>`}).join('');parts.push(`<div><b>خطوات الحل مفصّلة:</b><ol class="hint-steps">${items}</ol><small>الفراغ الأخير اتركه لنفسك ✍️</small></div>`)}if((step.blanks||[]).length){let sub=String(step.prefix||'');(step.blanks||[]).forEach(b=>{sub+='('+b.target+')'+(b.suffix||'')});parts.push(`<div><b>هكذا يكون التعويض:</b> ${mathHtml(sub)}</div>`);if(step.has_root)parts.push(`<div><b>تحت الجذر:</b> ${mathHtml((step.root_prefix||'')+' '+step.root_target+' '+(step.root_suffix||''))}</div>`);parts.push(`<div>احسب بالترتيب: الأقواس أولاً، ثم الضرب والقسمة، واكتب ${esc(step.result_label||'الناتج')} في خانة النتيجة.</div>`)}if(step.hint)parts.push(`<div><b>مفتاح الفكرة:</b> ${proseHtml(step.hint)}</div>`);return parts.join('')}
function choicesHtml(step){if(!(step.choices||[]).length)return '';return `<div class="mcq-box"><b>🧠 اختر التعليل الصحيح:</b>${step.choices.map((c,i)=>`<label class="mcq-opt"><input type="radio" name="mcq" value="${i}"><span>${c}</span></label>`).join('')}</div>`}
function fillInput(el,v){if(!el||v===undefined||v===null)return;el.value=String(v);el.dispatchEvent(new Event('input',{bubbles:true}))}
function revealStep(q,si,step){if((step.choices||[]).length){const r=document.querySelector('input[name="mcq"][value="'+(step.answer_index||0)+'"]');if(r)r.checked=true}(step.micro||[]).forEach((r,i)=>{const p=rowParts(r);if(p.target)fillInput(document.getElementById('micro-'+i),String(p.target).split('|')[0])});if(step.guided_work)fillInput($('#guidedWork'),(step.guided_work.accepted||[''])[0]);if(step.type){if(!step.micro_only)fillInput($('#proof'),step.target)}else{const ins=[...document.querySelectorAll('[data-blank]')];ins.forEach((el,i)=>fillInput(el,(step.blanks[i]||{}).target));if(step.has_root)fillInput($('#rootResult'),step.root_target);fillInput($('#result'),step.result_target)}state.revealed=state.revealed||{};state.revealed[key(q,si)]=true;save();toast('تم إدخال الإجابة الصحيحة في الفراغات — اضغط «تحقق» للتقدم')}
const SYMS=['Δ','ΔP','Δt','θ','π','×','÷','√','²','³','≈','±','→','←','°','m/s','m/s²','kg','N','N·s','kg·m/s','J','−','⌫'];let lastField=null;
function symbolPad(){return `<div class="sym-pad"><b>🔤 مكتبة الرموز</b><div class="sym-row">${SYMS.map(s=>`<button type="button" class="sym-key" data-sym="${attr(s)}">${esc(s)}</button>`).join('')}</div><small>اختر الفراغ أولاً ثم اضغط الرمز</small></div>`}
function wireSymbolPad(){const card=$('#stepCard');if(!card)return;card.querySelectorAll('input').forEach(el=>el.addEventListener('focus',()=>{lastField=el}));card.querySelectorAll('.sym-key').forEach(btn=>btn.addEventListener('click',()=>{const el=(lastField&&card.contains(lastField))?lastField:(card.querySelector('#proof')||card.querySelector('input'));if(!el)return;el.focus();const s=btn.getAttribute('data-sym');let a=el.value.length,b=el.value.length;try{if(el.selectionStart!==null&&el.selectionStart!==undefined){a=el.selectionStart;b=el.selectionEnd}}catch(e){}if(s==='⌫'){const p=(a===b&&a>0)?a-1:a;el.value=el.value.slice(0,p)+el.value.slice(b);try{el.setSelectionRange(p,p)}catch(e){}}else{el.value=el.value.slice(0,a)+s+el.value.slice(b);const c=a+s.length;try{el.setSelectionRange(c,c)}catch(e){}}el.dispatchEvent(new Event('input',{bubbles:true}))}))}

function key(q,s){return q.id+':'+s}
function qDone(q){return q.steps.every((_,i)=>state.done[key(q,i)])}
function total(){return UNIT.questions.reduce((n,q)=>n+q.steps.length,0)}
function metrics(){let n=Object.keys(state.done).filter(k=>state.done[k]).length,p=Math.round(n*100/total());$('#stepDone').textContent=n+'/'+total();$('#unitPct').textContent=p+'%';$('#xp').textContent=n*10+' XP';const all=load(PROGRESS_KEY,{});all[UNIT.id]={percent:p,done:n,total:total(),at:new Date().toISOString(),version:UNIT.version};localStorage.setItem(PROGRESS_KEY,JSON.stringify(all))}
function currentIndex(q){return Math.max(0,Math.min(state.steps[q.id]||0,q.steps.length-1))}
function unlocked(q,i){return i===0||!!state.done[key(q,i-1)]}
function setStep(q,i){if(!unlocked(q,i)){toast('أكمل الخطوة السابقة أولًا');return}state.steps[q.id]=i;save();render()}
function moveStep(delta){const q=UNIT.questions[state.q],i=currentIndex(q),next=i+delta;if(next<0||next>=q.steps.length)return;if(delta>0&&!state.done[key(q,i)]){toast('تحقق من هذه الخطوة قبل الانتقال');return}setStep(q,next)}

function renderNav(){const box=$('#qnav');box.innerHTML=UNIT.questions.map((q,i)=>`<button class="qbtn ${i===state.q?'active':''} ${qDone(q)?'done':''}" data-i="${i}">${qDone(q)?'✓ ':''}${esc(q.title)}</button>`).join('');box.querySelectorAll('button').forEach(b=>b.onclick=()=>{state.q=+b.dataset.i;save();render()})}
function renderStepStrip(q,si){
 const box=$('#steps');
 box.innerHTML=q.steps.map((s,i)=>{const done=!!state.done[key(q,i)],carry=done?summaryExpression(s):'';return `<button class="step-tile ${done?'done':i===si?'current':''} ${unlocked(q,i)?'':'locked'}" data-si="${i}" ${unlocked(q,i)?'':'disabled'}><span class="step-number">${done?'✓':i+1}</span><span class="step-title">${esc((s.title||'').replace(/^الخطوة\s*\d+\s*[:：-]?\s*/,''))}</span>${carry?`<span class="step-result">${mathHtml(carry)}</span>`:''}</button>`}).join('');
 box.querySelectorAll('.step-tile').forEach(b=>b.onclick=()=>setStep(q,+b.dataset.si));
 requestAnimationFrame(()=>{const cur=box.querySelector('.current');if(cur){const x=cur.offsetLeft-(box.clientWidth-cur.clientWidth)/2;box.scrollTo({left:x,behavior:'smooth'})}});
 wireHorizontalDrag(box);
}
function wireHorizontalDrag(el){if(el.dataset.dragReady)return;el.dataset.dragReady='1';let down=false,start=0,left=0,moved=false;el.addEventListener('pointerdown',e=>{if(e.pointerType!=='mouse')return;down=true;moved=false;start=e.clientX;left=el.scrollLeft;el.classList.add('dragging');el.setPointerCapture(e.pointerId)});el.addEventListener('pointermove',e=>{if(!down)return;const dx=e.clientX-start;if(Math.abs(dx)>5)moved=true;el.scrollLeft=left-dx});el.addEventListener('pointerup',e=>{down=false;el.classList.remove('dragging');try{el.releasePointerCapture(e.pointerId)}catch(_){}});el.addEventListener('click',e=>{if(moved){e.preventDefault();e.stopPropagation();moved=false}},true)}
function wireCardSwipe(){const card=$('#stepCard');let x0=null,y0=null;card.onpointerdown=e=>{if(e.target.closest('input,button'))return;x0=e.clientX;y0=e.clientY};card.onpointerup=e=>{if(x0===null)return;const dx=e.clientX-x0,dy=e.clientY-y0;x0=y0=null;if(Math.abs(dx)>70&&Math.abs(dx)>Math.abs(dy)*1.25)moveStep(dx<0?1:-1)}}
function microHtml(step){const rows=[...(step.micro||[]),...(step.micro2||[])];return rows.map((x,idx)=>{const p=rowParts(x);let eq=p.eq;if(p.target)eq=eq.replace('?',String(p.target).split('|')[0]);return `<div class="micro"><b>${idx+1}</b><div><strong>${esc(p.desc)}</strong>${eq?`<div class="micro-eq">${mathHtml(eq)}</div>`:''}</div></div>`}).join('')}
function solution(step){let result=step.completed_display||'';if(!result&&step.result_target!==undefined)result=(step.result_label||'النتيجة')+' '+step.result_target;const guided=step.guided_work?`<div class="guided-solution"><span>طريقة التحويل الصحيحة</span>${mathHtml(step.guided_work.equation_left+' '+step.guided_work.reveal)}</div>`:'';return `<div class="solution"><b>✅ اكتملت الخطوة</b>${guided}${microHtml(step)}${result?`<div class="result-eq">${equationOrText(result)}</div>`:''}</div>`}
/* ROOT_INTERMEDIATE_V1 */
function formulaInteractive(step,done){
 let out='<div class="formula-scroll"><div class="formula">';
 out+=`<span>${mathHtml(step.prefix||'')}</span>`;
 (step.blanks||[]).forEach((b,i)=>{out+=`<input data-blank="${i}" inputmode="decimal" ${done?'disabled':''} placeholder="${attr(b.label||'?')}"><span>${mathHtml(b.suffix||'')}</span>`});
 out+='</div></div>';
 if(step.has_root){
  out+=`<div class="result-row root-result-row"><b>المرحلة الوسيطة</b><div class="formula"><span>${mathHtml(step.root_prefix||'')}</span><input id="rootResult" inputmode="decimal" ${done?'disabled':''} placeholder="ما تحت الجذر"><span>${mathHtml(step.root_suffix||'')}</span></div></div>`;
 }
 out+=`<div class="result-row"><b>${esc(step.result_label||'الناتج')}</b><input id="result" inputmode="decimal" ${done?'disabled':''} placeholder="القيمة النهائية"></div>`;
 return out
}
function formulaProof(step,done){if(done)return '';if(step.choices&&step.choices.length)return choicesHtml(step);if(step.micro_only||(step.micro&&step.micro.length))return `${microPracticeHtml(step,false)}${choicesHtml(step)}<div class="notice">✅ أكمل فراغات الخطوات أعلاه بالترتيب ثم اضغط «تحقق».</div>`;return `${microPracticeHtml(step,false)}${guidedWorkHtml(step.guided_work,false)}<div class="answer-label final-label">${esc('الخطوة الأخيرة — '+(step.label||'اكتب النتيجة النهائية:'))}</div><div class="formula-scroll"><div class="formula proof-input"><span>${mathHtml(step.prefix||'')}</span><input id="proof" placeholder="اكتب الإجابة هنا"><span>${mathHtml(step.suffix||'')}</span></div></div><div class="proof-preview">${mathHtml(maskAnswer(step.latex_preview||'')||'أكمل العلاقة الرمزية')}</div>`}
function checkStep(q,si,step){
 const k=key(q,si);
 if(step.micro_only||step.choices||(step.micro&&step.micro.length)){if(!(step.choices||[]).length&&!validateMicroPractice(step))return;if((step.choices||[]).length){const sel=document.querySelector('input[name="mcq"]:checked');if(!sel)return toast('اختر التعليل الصحيح أولاً');if(+sel.value!==(step.answer_index||0))return toast('التعليل قريب لكنه غير دقيق — أعد المحاولة')}state.done[k]=true;save();toast('أحسنت — اكتملت الخطوة');render();return}
 if(step.type&&!validateMicroPractice(step))return;
 if(step.guided_work){
  const w=$('#guidedWork')?.value||'';
  if(!w)return toast('اكتب أولًا الكسر الأول × مقلوب الكسر الثاني');
  const got=workNorm(w),accepted=(step.guided_work.accepted||[]).map(workNorm);
  if(!accepted.includes(got))return toast('راجع المقلوب: اقلب الكسر الثاني فقط ثم اضرب')
 }
 if(step.type){
  const v=$('#proof')?.value||'';
  if(!v)return toast('اكتب النتيجة النهائية أيضًا');
  const target=step.target;
  if(typeof target==='number'){
   const got=num(v);
   if(got===null||!close(got,target,step.tol||.01))return toast('النتيجة النهائية غير صحيحة بعد')
  }else if(!microValueMatches(v,target,!!step.case_sensitive))return toast('راجع الرموز ثم حاول مجددًا')
 }else{
  const ins=[...document.querySelectorAll('[data-blank]')];
  if(ins.some(x=>num(x.value)===null))return toast('أدخل قيم التعويض أولًا');
  for(let i=0;i<ins.length;i++)if(!close(num(ins[i].value),step.blanks[i].target,.001))return toast('إحدى قيم التعويض غير صحيحة');
  if(step.has_root){
   const rv=num($('#rootResult')?.value||'');
   if(rv===null)return toast('أدخل أولًا قيمة المرحلة الواقعة تحت الجذر');
   if(!close(rv,step.root_target,.01))return toast('راجع قيمة المرحلة الواقعة تحت الجذر')
  }
  const r=num($('#result')?.value);
  if(r===null)return toast('أدخل النتيجة النهائية');
  const targets=[step.result_target,step.alt_result_target].filter(x=>x!==undefined);
  if(!targets.some(t=>close(r,t,step.result_tol||.01)))return toast('النتيجة غير صحيحة بعد')
 }
 state.done[k]=true;save();toast('أحسنت — اكتملت الخطوة');render()
}
// PHYSICS_BOOK_FIGURES_V1
function questionFigure(q){if(!q.figure)return '';return `<figure class="question-figure"><img src="${attr(q.figure)}" alt="${attr(q.figure_caption||q.title||'رسم التمرين')}">${q.figure_caption?`<figcaption>${esc(q.figure_caption)}</figcaption>`:''}</figure>`}
let autoNextBusy=false;
function autoNextQuestion(){
 if(autoNextBusy)return;
 const q=UNIT.questions[state.q];if(!q)return;
 const all=q.steps.every((s,i)=>!!state.done[key(q,i)]);
 if(!all)return;
 if(state.q>=UNIT.questions.length-1)return;
 autoNextBusy=true;
 toast('🎉 أحسنت! ننتقل إلى التمرين التالي…');
 setTimeout(()=>{autoNextBusy=false;state.q=state.q+1;save();render()},1600);
}
function render(){
 setTimeout(autoNextQuestion,0);
 const q=UNIT.questions[state.q],si=currentIndex(q),step=q.steps[si],k=key(q,si),done=!!state.done[k];
 renderNav();renderStepStrip(q,si);
 $('#statement').innerHTML=`<small><span class="type-chip ${q.type==='proof'?'proof':'interactive'}">${q.type==='proof'?'إثبات رمزي':'تمرين تفاعلي'}</span></small><h2>${esc(q.title)}</h2><p>${proseHtml(q.text)}</p>${questionFigure(q)}${qDone(q)&&q.conclusion?`<div class="solution">${proseHtml(q.conclusion)}</div>`:''}`;
 $('#stepCard').innerHTML=`<div class="step-head"><small>الخطوة ${si+1} من ${q.steps.length}</small><span class="swipe-note">↔ اسحب الخطوات أفقيًا</span></div><h2>${esc(step.title)}</h2><div class="law-guide-box"><b>القانون / المعطى</b><div>${proseHtml(step.law||'')}</div></div>${step.simple_explain?`<div class="explain-box">${proseHtml(step.simple_explain)}</div>`:''}${referencesHtml(q,si,step)}${step.type?formulaProof(step,done):formulaInteractive(step,done)}${done?'':symbolPad()}<div class="navrow"><button id="hint" class="btn outline">💡 تلميح مفصّل</button><button id="reveal" class="btn outline" ${done?'disabled':''}>✅ الإجابة الصحيحة</button><button id="check" class="btn primary" ${done?'disabled':''}>تحقق</button></div><div id="hintBox">${state.hints[k]&&!done?`<div class="notice hint-rich">💡 <b>شرح موجّه:</b>${hintHtml(step)}</div>`:''}</div>${done?solution(step):''}<div class="navrow"><button id="prev" class="btn outline" ${si===0?'disabled':''}>السابق</button><button id="next" class="btn blue" ${!done||si===q.steps.length-1?'disabled':''}>التالي</button></div>`;
 $('#hint').onclick=()=>{state.hints[k]=true;save();render()};const _rv=$('#reveal');if(_rv)_rv.onclick=()=>revealStep(q,si,step);$('#check').onclick=()=>checkStep(q,si,step);$('#prev').onclick=()=>moveStep(-1);$('#next').onclick=()=>moveStep(1);wireSymbolPad();wireCardSwipe();metrics();if(pane)showPane(pane)
}
const formulas=UNIT.formulas||['P = m·v','K = P²/(2m)','I = F·Δt','I = ΔP','F = ΔP/Δt','ΣPᵢ = ΣP𝒇'];
function formulaPaneItem(x){if(Array.isArray(x))return `<div class="law mini-law"><b>${esc(x[0])}</b>${mathHtml(x[1])}</div>`;return `<div class="law mini-law">${mathHtml(x)}</div>`}
function calcHtml(){const keys=['7','8','9','÷','sin(','4','5','6','×','cos(','1','2','3','-','√(','0','.','(',')','+','π','^','⌫','AC','='];return `<h3>حاسبة علمية</h3><div id="display" class="calc-display">0</div><div class="calc-grid">${keys.map(k=>`<button class="${'=+-×÷^'.includes(k)?'op':''} ${k==='='?'equal':''}" data-k="${k}">${k}</button>`).join('')}</div>`}
function showPane(which){pane=which;const p=$('#dockPanel');p.classList.remove('hidden');if(which==='laws')p.innerHTML='<h3>ورقة القوانين</h3>'+formulas.map(formulaPaneItem).join('');if(which==='stmt'){const q=UNIT.questions[state.q];p.innerHTML=`<h3>نص التمرين</h3><p>${proseHtml(q.text)}</p>`}if(which==='calc'){p.innerHTML=calcHtml();wireCalc()}}
document.querySelectorAll('.rail button').forEach(b=>b.onclick=()=>pane===b.dataset.pane?(pane='', $('#dockPanel').classList.add('hidden')):showPane(b.dataset.pane));
function wireCalc(){let e='',disp=$('#display');document.querySelectorAll('.calc-grid button').forEach(b=>b.onclick=()=>{let k=b.dataset.k;if(k==='AC')e='';else if(k==='⌫')e=e.slice(0,-1);else if(k==='='){try{let x=e.replace(/π/g,'Math.PI').replace(/×/g,'*').replace(/÷/g,'/').replace(/\^/g,'**').replace(/√\(/g,'Math.sqrt(').replace(/sin\(/g,'Math.sin(Math.PI/180*').replace(/cos\(/g,'Math.cos(Math.PI/180*');e=String(Math.round(Function('return ('+x+')')()*1e10)/1e10)}catch(_){e='خطأ'}}else e+=k;disp.textContent=e||'0'})}
function net(){const on=navigator.onLine;$('#net').textContent=on?'متصل':'دون إنترنت';$('#net').classList.toggle('offline',!on);$('#mode').textContent=on?'متصل':'أوفلاين'}
addEventListener('online',net);addEventListener('offline',net);net();render();
