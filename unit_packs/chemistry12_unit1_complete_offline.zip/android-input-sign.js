/* ANDROID_NUMERIC_SIGN_V1 */
(()=>{
'use strict';
function toggle(input,button){
 let value=String(input.value||'').trim().replace(/^−/,'-');
 if(value.startsWith('-')) value=value.slice(1); else if(value.startsWith('+')) value='-'+value.slice(1); else value='-'+value;
 input.value=value; button.classList.toggle('negative',value.startsWith('-'));
 input.dispatchEvent(new Event('input',{bubbles:true})); input.dispatchEvent(new Event('change',{bubbles:true}));
 input.focus({preventScroll:true}); try{input.setSelectionRange(value.length,value.length)}catch(_){}
}
function decorate(root=document){
 root.querySelectorAll('input[inputmode="decimal"],input[inputmode="numeric"],input[type="number"]').forEach(input=>{
  if(input.dataset.signReady==='1'||input.disabled||input.readOnly)return;
  input.dataset.signReady='1';
  const button=document.createElement('button'); button.type='button'; button.className='android-sign-btn';
  button.textContent='±'; button.setAttribute('aria-label','تغيير إشارة العدد بين موجب وسالب'); button.title='تغيير الإشارة (+/−)';
  const act=event=>{event.preventDefault();event.stopPropagation();toggle(input,button)};
  if(window.PointerEvent) button.addEventListener('pointerdown',act); else button.addEventListener('touchstart',act,{passive:false});
  input.insertAdjacentElement('afterend',button);
 })
}
decorate();new MutationObserver(mutations=>mutations.forEach(m=>m.addedNodes.forEach(n=>{if(n.nodeType===1)decorate(n.matches&&n.matches('input')?n.parentElement:n)}))).observe(document.documentElement,{childList:true,subtree:true});
})();
